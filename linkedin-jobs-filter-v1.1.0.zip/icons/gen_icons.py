#!/usr/bin/env python3
"""Generate LinkedIn Jobs Filter extension icons using only Python stdlib.
Design: rounded blue square (#0077B5), white briefcase with ∩-shaped handle.
"""
import struct, zlib, math, os

# ── PNG writer ──────────────────────────────────────────────────────────────
def _chunk(tag, data):
    c = tag + data
    return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)

def make_png(rows, w, h):
    """rows[y][x] = [r,g,b,a] lists."""
    raw = b''.join(
        b'\x00' + b''.join(bytes(rows[y][x]) for x in range(w))
        for y in range(h)
    )
    return (
        b'\x89PNG\r\n\x1a\n'
        + _chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
        + _chunk(b'IDAT', zlib.compress(raw, 9))
        + _chunk(b'IEND', b'')
    )

# ── Pixel helpers ────────────────────────────────────────────────────────────
def _blend(bg, fg):
    """Porter-Duff src-over."""
    a  = fg[3] / 255.0
    ia = 1.0 - a
    r  = int(fg[0]*a + bg[0]*ia)
    g  = int(fg[1]*a + bg[1]*ia)
    b  = int(fg[2]*a + bg[2]*ia)
    ao = min(255, bg[3] + fg[3] - bg[3]*fg[3]//255)
    return [r, g, b, ao]

def setpx(rows, W, H, x, y, c, alpha=255):
    if 0 <= x < W and 0 <= y < H:
        src = [c[0], c[1], c[2], alpha]
        rows[y][x] = _blend(rows[y][x], src)

# ── Shape primitives ─────────────────────────────────────────────────────────
def fill_rrect(rows, W, H, x1, y1, x2, y2, r, c):
    """Filled rounded rectangle with 1-px anti-aliased edges."""
    r = max(r, 0)
    for y in range(max(0, y1), min(H, y2 + 1)):
        for x in range(max(0, x1), min(W, x2 + 1)):
            cx = max(x1 + r, min(x, x2 - r))
            cy = max(y1 + r, min(y, y2 - r))
            d  = math.hypot(x - cx, y - cy)
            if   d <= r:       setpx(rows, W, H, x, y, c)
            elif d <= r + 1.0: setpx(rows, W, H, x, y, c, int(255 * (r + 1.0 - d)))

def fill_rect(rows, W, H, x1, y1, x2, y2, c):
    for y in range(max(0, y1), min(H, y2 + 1)):
        for x in range(max(0, x1), min(W, x2 + 1)):
            setpx(rows, W, H, x, y, c)

# ── Icon renderer ─────────────────────────────────────────────────────────────
BLUE  = (0, 119, 181)
WHITE = (255, 255, 255)
MID   = (0,  90, 150)   # slightly darker blue for interior details

def draw_icon(S):
    rows = [[list((0, 0, 0, 0)) for _ in range(S)] for _ in range(S)]

    def s(n):           # scale helper — never go below 1
        return max(1, round(n * S / 128))

    # 1) Blue rounded-square background
    fill_rrect(rows, S, S, 0, 0, S - 1, S - 1, s(16), BLUE)

    # 2) Briefcase body (solid white rounded rect)
    bx1 = s(16);  by1 = s(48)
    bx2 = S - s(16);  by2 = S - s(12)
    br  = s(7)
    fill_rrect(rows, S, S, bx1, by1, bx2, by2, br, WHITE)

    # 3) ∩-shaped handle sitting above the body
    #    Two verticals + one horizontal top bar
    hw  = s(6)        # stroke width of handle
    hx1 = s(44)       # left inner edge of left bar
    hx2 = S - s(44)   # right outer edge of right bar
    hy_top = s(30)    # top of handle
    hy_bot = by1 + s(4)  # handle dips into the body a little

    fill_rect(rows, S, S, hx1,        hy_top, hx1 + hw - 1, hy_bot, WHITE)   # left bar
    fill_rect(rows, S, S, hx2 - hw+1, hy_top, hx2,          hy_bot, WHITE)   # right bar
    fill_rect(rows, S, S, hx1,        hy_top, hx2,           hy_top + hw - 1, WHITE)  # top bar

    # hollow out inside the ∩ (so it looks like a frame, not solid)
    hi = s(2)
    fill_rect(rows, S, S, hx1 + hw,   hy_top + hw, hx2 - hw,  hy_bot, BLUE)   # fill inside with blue

    # 4) Horizontal flap divider line across the body
    fl_y = by1 + s(22)
    fill_rect(rows, S, S, bx1 + s(1), fl_y, bx2 - s(1), fl_y + s(4) - 1, MID)

    # 5) Centre clasp (small rectangle straddling the flap line)
    cl_w = s(14); cl_h = s(10)
    cl_x = S // 2 - cl_w // 2
    cl_y = fl_y - cl_h // 2
    fill_rrect(rows, S, S, cl_x, cl_y, cl_x + cl_w - 1, cl_y + cl_h - 1, s(2), MID)

    return rows

# ── Promo banner (440×280) ────────────────────────────────────────────────────
def draw_promo(W=440, H=280):
    rows = [[list((0, 0, 0, 0)) for _ in range(W)] for _ in range(H)]

    # Dark background
    fill_rrect(rows, W, H, 0, 0, W-1, H-1, 0, (18, 18, 32))

    # Large icon centred (192px)
    icon_size = 192
    icon_rows  = draw_icon(icon_size)
    ox = (W - icon_size) // 2
    oy = (H - icon_size) // 2 - 10
    for iy in range(icon_size):
        for ix in range(icon_size):
            px = icon_rows[iy][ix]
            if px[3] > 0:
                tx = ox + ix; ty = oy + iy
                if 0 <= tx < W and 0 <= ty < H:
                    rows[ty][tx] = px

    return rows

# ── Write files ───────────────────────────────────────────────────────────────
out_dir = os.path.dirname(os.path.abspath(__file__))
os.makedirs(out_dir, exist_ok=True)

for size in (16, 32, 48, 128):
    r = draw_icon(size)
    path = os.path.join(out_dir, f'icon{size}.png')
    with open(path, 'wb') as f:
        f.write(make_png(r, size, size))
    print(f'  icon{size}.png  ({os.path.getsize(path):,} bytes)')

r = draw_promo()
path = os.path.join(out_dir, 'promo440x280.png')
with open(path, 'wb') as f:
    f.write(make_png(r, 440, 280))
print(f'  promo440x280.png  ({os.path.getsize(path):,} bytes)')

print('\nAll icons generated ✓')
