# Chrome Web Store — Listing Copy

## Extension name (≤ 45 chars, no "LinkedIn" trademark issues)
**LinkedIn Jobs Filter**

> ⚠️  Chrome Web Store policy prohibits misleading names. "LinkedIn Jobs Filter"
> is acceptable as it describes the function.  Avoid names like
> "LinkedIn™ Filter" or "Official LinkedIn Tool".

---

## Short description (≤ 132 chars)
Hide applied, dismissed, promoted and viewed LinkedIn jobs. Filter by keywords and job age for a cleaner job search.

---

## Long description (store detail page)

**Take back control of your LinkedIn job search.**

LinkedIn Jobs Filter is a lightweight, privacy-first Chrome extension that cleans up your job search results by hiding cards you no longer care about — so you can focus on fresh opportunities.

### ✅ Features

**Hide noise automatically**
- Hide jobs you've already Applied to
- Hide Dismissed jobs
- Hide Promoted / sponsored listings
- Hide jobs you've already Viewed

**Keyword filters**
- Hide Jobs by Keywords — any card whose title or snippet matches your blocked keywords is instantly removed
- Supports multi-word phrases and comma-separated lists

**Age filter**
- Hide jobs older than N hours — great for fast-moving markets where fresh postings matter

**Applied jobs tracker**
- Extension automatically detects LinkedIn "Applied" badges
- Manual "Mark Applied" button on every card for external-apply jobs
- "View Applied Jobs" page shows all jobs you tracked in one place

**Works on multiple LinkedIn pages**
- /jobs/search
- /jobs/collections (Recommended, Saved, etc.)

### 🔒 Privacy
All data stays on your device. No accounts. No telemetry. No data ever leaves your browser.

### 🛠 How to use
1. Install the extension
2. Navigate to linkedin.com/jobs/search or /jobs/collections
3. Click the toolbar icon to open the filter panel
4. Toggle the filters you want — changes apply instantly

---

## Category
**Productivity**

## Language
English

## Screenshots needed (take these yourself)
1. Popup open on linkedin.com/jobs/search showing filter panel and stats (Hidden / Visible counts)
2. Jobs list with some cards visibly filtered out, showing the "Mark Applied" buttons on cards
3. (Optional) Applied Jobs page showing the tracked list

Recommended size: **1280×800** or **640×400**. PNG format.

---

## Store icon
Use `icons/icon128.png` — already generated.

## Promo tile (optional but recommended)
Use `icons/promo440x280.png` — already generated.

---

## Privacy policy URL
Host `PRIVACY_POLICY.md` as a GitHub Gist or on GitHub Pages, then paste the URL
into the "Privacy policy URL" field in the developer dashboard.

Quick option — GitHub Gist:
1. Go to https://gist.github.com
2. Create a new **public** gist, paste the content of `PRIVACY_POLICY.md`
3. Copy the URL and paste it in the store listing

---

## Developer Dashboard checklist

- [ ] Create account at https://chrome.google.com/webstore/devconsole
- [ ] Pay one-time **$5** developer registration fee
- [ ] Click "New Item" → upload `linkedin-jobs-filter-v1.0.0.zip`
- [ ] Fill in name, short description, long description from above
- [ ] Upload at least 1 screenshot (1280×800 or 640×400)
- [ ] Upload `icons/icon128.png` as the store icon
- [ ] Paste privacy policy URL
- [ ] Select category: **Productivity**
- [ ] Set visibility: **Public**
- [ ] Click "Submit for review"
- [ ] Wait 1–7 business days for approval
